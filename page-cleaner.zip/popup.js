// Popup script for Page Cleaner extension

document.addEventListener('DOMContentLoaded', function () {
    console.log('Page Cleaner popup loaded');
});